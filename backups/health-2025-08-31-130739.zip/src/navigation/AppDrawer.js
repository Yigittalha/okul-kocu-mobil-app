import React, { useContext } from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { SessionContext } from "../state/session";

// Import dashboard screens
import AdminDashboard from "../app/admin/AdminDashboard";
import TeacherDashboard from "../app/teacher/TeacherDashboard";
import ParentDashboard from "../app/parent/ParentDashboard";
// Import TeachersList and StudentsList screens
import TeachersList from "../app/common/TeachersList";
import StudentsList from "../app/common/StudentsList";

const Stack = createNativeStackNavigator();

/**
 * Ana çekmece navigasyonu
 * Not: SlideMenu component'i ayrı bir dosyaya taşındı
 * ve döngüsel bağımlılık ortadan kaldırıldı
 */
export default function AppDrawer() {
  const { role } = useContext(SessionContext);

  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      {role === "admin" && (
        <>
          <Stack.Screen name="AdminDashboard" component={AdminDashboard} />
          <Stack.Screen name="TeachersList" component={TeachersList} />
          <Stack.Screen name="StudentsList" component={StudentsList} />
        </>
      )}
      {role === "teacher" && (
        <>
          <Stack.Screen name="TeacherDashboard" component={TeacherDashboard} />
          <Stack.Screen name="TeachersList" component={TeachersList} />
          <Stack.Screen name="StudentsList" component={StudentsList} />
        </>
      )}
      {role === "parent" && (
        <Stack.Screen name="ParentDashboard" component={ParentDashboard} />
      )}
    </Stack.Navigator>
  );
}
