export const schools = [
  { label: 'İstanbul Anadolu Lisesi', value: 'IAL' },
  { label: 'Edirne Fen Lisesi', value: 'EFL' },
  { label: 'Kadıköy Ortaokulu', value: 'KOO' },
  { label: 'Çorlu MTAL', value: 'CMTAL' },
  { label: 'Ankara Atatürk Lisesi', value: 'AAL' },
]; 